Name: Albara Mehene

What I did:
	When I started the sierpinski triangle, I was stumped. So what I did first was draw a base triangle that can fit the window. Thankfully with a bit of tweaking and guessing, I figured out how to put the size of the triangle in the window. Then my second opbjective was to create a triangle in the middle. So I created a recursive triangle. I would pass it the previous shape and then used the previous points and divded them by 2. Then would store the points. After that I called the function 3 times to change each point to another side. I thought this was the fun part, because of how I just needed to figure out which point i needed from the previous triangle and which one I didn't . Over all the sierpenski triangle was hard for me to implement but fun at the same time.

	Thankfully my orginial was time consuming in the begnning because of figuring out which formula to use. After that, it was fun and easy for me go through. I enjoyed making my own shape. I might try making other fractal shapes in my spare time.

	Time invested: 5 hours

	Comments:
		I actually enjoyed this project a lot. Hopefully we have similar projects like this one.
