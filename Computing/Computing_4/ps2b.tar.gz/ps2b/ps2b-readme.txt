Name: Albara Mehene
Date: 10/1/2016
Computing IV

Statement: The Function of my program was the user would enter, the input, output, password, and the tap. After that, I created a LFSR and a copy of the image of the orginal input. I passed the LFSR and a copy of the image. Then I took the size of the image, iterated through the window. Every pixel would be given a 8 bit type. for the the red, green, and blue. To do that, I Xored each color with the 8 bit type. Then I stored it by using getPixel. Then returned it. I opened 2 windows, one for the original and the other of the encryption.