Name: Albara Mehene

How I implemented the step function:
	I created 2 integers called bit and size. Size was used to to store the amount of size in the array of stringsBit is used to store the results of the Xor function between the characters. I just stored the front end of the array then the compared the total amount and subtracted by the the given tap. I subtracted 1 for the null terminator. After that, I looked up the erase function them erased the front element. Basically the last part, is the condition of its 1 , it would push the element and store the result at the end of the array. Anything else would be 0.

	3.Did not have enough time to make more. I will test more out, after submitting it now.