Name: Albara Mehene
Email: Albara_Mehene@student.uml.edu
Class: Monday night classes

Degree of Success:
90%

Description:
The steps I took for this project was I first took the code that was provided by Hendrickson. The program already stores the first and second input using a pointer that saves the address of binum1. After that I just added to a variable sum and lodded into the accumlator. The reason I believe I had a 90% percent success is because I was not able to print out the text for the sum and overflow. The issue was after printing the text it required the use to enter a input. This is necause after the nextw function comes the input request. I believe I would have needded to create a diffrent nextw to print out the text but I didn't come around to do so. Thus I was able to print out the sum and was able to print out the sum showing 0 in the accumlator and -1 when its a overflow. Overall I did manage to finish this in a timely manner. I believe that I was having issues with the transmitter because the debugger would be in a infinite loop. So i needed to turn it off and on to be able to stop this issue.
